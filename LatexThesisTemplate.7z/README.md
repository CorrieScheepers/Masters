I recommend using git to backup and manage your document progress.
